﻿namespace Core.AppService.Business
{
    public interface IBaseService<T> where T : class
    {
    }
}
