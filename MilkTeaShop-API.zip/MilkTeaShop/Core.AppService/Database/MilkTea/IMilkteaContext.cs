﻿namespace Core.AppService.Database.MilkTea
{
    public interface IMilkteaContext : IDatabase
    {
    }
}
