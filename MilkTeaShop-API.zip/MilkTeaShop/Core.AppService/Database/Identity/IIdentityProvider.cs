﻿namespace Core.AppService.Database.Identity
{
    public interface IIdentityProvider : IDatabase
    {

    }
}
