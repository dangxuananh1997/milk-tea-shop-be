﻿namespace Core.AppService.Database
{
    public interface IDatabase
    {
        object GetContext();
    }
}
